﻿WNM (Weighted N-gram Model) MT evaluation package
	extends BLEU MT evaluation method (Papineni et al., 2002) 
	with vector space model weights

	authors: Bogdan Babych, Anthony Hartley

 GET LATEST UPDATES FROM
 http://www.comp.leeds.ac.uk/bogdan/evalMT.html
 


version 01-1
2004-05-17

files:
17/05/2004  14:23    <DIR>          documentation

17/05/2004  14:15            13,824 correlWithHumanScores.xls
17/05/2004  14:37               506 debug-tmp.txt
05/02/2004  17:26               104 humanSC-ADE-WP.txt
05/02/2004  17:27               104 humanSC-FLU-WP.txt
03/02/2004  03:34            23,042 tw00humanRef.txt
03/02/2004  03:34            25,314 tw01sysA-base.txt
03/02/2004  03:34            25,159 tw02sysA-dict.txt
03/02/2004  03:34            27,192 tw03sysB-base.txt
03/02/2004  03:34            26,133 tw04sysB-dict.txt
17/05/2004  14:25             3,320 wnm-01-1-doc.txt
17/05/2004  14:16               641 wnm-01-1.bat
17/05/2004  14:36            12,115 wnm-01-1.pl
16/05/2004  14:05            90,456 wnm-frqEnglish-darpa94e.txt
16/05/2004  14:05            91,554 wnm-frqEnglish-darpa94r.txt
17/05/2004  14:37               780 wnm-results.txt
17/05/2004  14:48              1213 _readme.txt
              16 File(s)        340,244 bytes
