bleu -t test.txt -r ref.txt
; bleu -t <test_file> -r <reference_file>
